const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors')

var ws = require('ws');

const routes = require('./routes/routes');
const app = express();

app.use(express.json());

app.use(bodyParser.json());
app.use(cors({origin: '*'}))

app.use('/api', routes)






app.listen(8000, () => {
    console.log(`Server Started at ${8000}`)
 })

 
 //Import la librairie serialport
 var Serialport = require('serialport');

 //Import les references à partir de firebase
 const { set, ref, onValue } = require('firebase/database');
 //Import la configuration pour le realtime database
 const { databaserRealtime } = require('./firestoreConfig');
// const ventillo = require('./routes/test');
const { Server } = require('socket.io');
 //Lecture du port
 var Readline = Serialport.parsers.Readline;
 
//  console.log(Readline);
 
// Instanciation de la classe Serialport
 var port = new Serialport('/dev/ttyUSB0', {
     baudRate: 9600
 });
 
 // Recuperation des données venue du port
 var parser = port.pipe(new Readline({ delimiter: '\r\n' }));
 
//  parser.on('readable', function() {
//      console.log('Connexion ouverte');
//  });


app.use('/vent', (res,req)=>{
  console.log(req.params);
})

 let msg2 ='0';

 var router = express.Router();
 
 var status=""
 router.get('/vent/:id', (req,res)=>{
  const uid = req.params.id
   status = ''+uid;
  console.log(status);
  return res.send(uid);
})


// io.on("connection", (socket) => {
//   console.log(`socket ${socket.id} connected`);

//   // send an event to the client
//   socket.emit("foo", "bar");

//   socket.on("vent", (e) => {
//     // an event was received from the client
//     console.log(e);
//   })
// })

 

 //Evennement d'ecoute pour l'emission des donnees
 parser.on('data', data =>{
     console.log('humidite :', data.slice(0,2));
     console.log('Temperature :', data.slice(3,5));
      console.log(data);
     if (data.slice(0,2) && data.slice(3,5)) {
       setTimeout(() => {
        addRealtimeWeather(data.slice(0,2 ),data.slice(3,5));
       }, 2000);
     }

    var tempe = parseInt(data.slice(0, 2));
    var humi = parseInt(data.slice(3, 5));

    const starCountRef = ref(databaserRealtime,  'ventilo/');
    let status="";
    onValue(starCountRef, (snapshot) => {
      const data = snapshot.val();
      status = ""+data.isAuth;
      console.log(status);
      port.write(status);
    });
      
  
    var datHeure = new Date();
    var min = datHeure.getMinutes();
    var heur = datHeure.getHours(); //heure
    var sec = datHeure.getSeconds(); //secondes
    var mois = datHeure.getDate(); //renvoie le chiffre du jour du mois 
    var numMois = datHeure.getMonth() + 1; //le mois en chiffre
    var laDate = datHeure.getFullYear(); // me renvoie en chiffre l'annee
    if (numMois < 10) { numMois = '0' + numMois; }
    if (mois < 10) { mois = '0' + mois; }
    if (sec < 10) { sec = '0' + sec; }
    if (min < 10) { min = '0' + min; }
    var heureInsertion = heur + ':' + min + ':' + sec;
    var heureEtDate = mois + '/' + numMois + '/' + laDate;
  

    if ((heur == 08 && min == 00 && sec == 00) || (heur == 12 && min == 00 && sec == 00) || (heur == 19 && min == 00 && sec == 00)) {
      
  
      if ((heur == 08 && min == 00 && sec == 00)) {
          
          set(ref(databaserRealtime, 'humidite'), {
            matin: humi,
          })
          set(ref(databaserRealtime, 'temperature'), {
            matin: tempe,
          })

      }else if(heur == 12 && min == 00 && sec == 00){
        set(ref(databaserRealtime, 'humidite'), {
          midi: humi,
        })
        set(ref(databaserRealtime, 'temperature'), {
          midi: tempe,
        })
      }else{
        set(ref(databaserRealtime, 'humidite'), {
          soir : humi
        })
        set(ref(databaserRealtime, 'temperature'), {
          soir: tempe,
        })
      }  
    }
   
     
 });

  const addRealtimeWeather =(hum, temp)=>{
         set(ref(databaserRealtime, 'realTime'), {
            hum:hum,
            temp:temp
      });
  }

  

  // const getRealtimeData=()=>{
  //   const starCountRef = ref(databaserRealtime,  'ventilo/');
  //   let status;
  //   onValue(starCountRef, (snapshot) => {
  //     const data = snapshot.val();
  //     // updateStarCount(postElement, data);
  //     // console.log(data.isAuth);
  //     status = data.isAuth;
  //   });
  //   console.log(status);
  //   return status
  // }

// let message = '2'
// port.write(message, function(err) {
//   if (err) {
//     return console.log("Error on write: ", err.message);
//   }
//   port.write(message);
//   // io.emit('temp', message)
//   console.log(message);
// });

// parser.on('readable', function(data) {
//     // console.log(readable);
//     // io.emit('temp', data);
//     console.log(data);
//     //decoupe des donnees venant de la carte Arduino
//     var temperature = data.slice(0, 2); //decoupe de la temperature
//     var humidite = data.slice(5, 7); //decoupe de l'humidite
//     //calcul de la date et l'heure 
//     var datHeure = new Date();
//     var min = datHeure.getMinutes();
//     var heur = datHeure.getHours(); //heure
//     var sec = datHeure.getSeconds(); //secondes
//     var mois = datHeure.getDate(); //renvoie le chiffre du jour du mois 
//     var numMois = datHeure.getMonth() + 1; //le mois en chiffre
//     var laDate = datHeure.getFullYear(); // me renvoie en chiffre l'annee
//     if (numMois < 10) { numMois = '0' + numMois; }
//     if (mois < 10) { mois = '0' + mois; }
//     if (sec < 10) { sec = '0' + sec; }
//     if (min < 10) { min = '0' + min; }
//     var heureInsertion = heur + ':' + min + ':' + sec;
//     var heureEtDate = mois + '/' + numMois + '/' + laDate;
//     // TODO

//     //fin test
//     if ((heur == 08 && min == 00 && sec == 00) || (heur == 12 && min == 00 && sec == 00) || (heur == 19 && min == 00 && sec == 00)) {
//         var tempe = parseInt(temperature);
//         var humi = parseInt(humidite);
//         console.log("En number" + tempe);
//         console.log("En chaine de caractere" + temperature);
//         //l'objet qui contient la temperature, humidite et la date
//         var tempEtHum = { 'Temperature': tempe, 'Humidite': humi, 'Date': heureEtDate, 'Heure': heureInsertion };
//         //Connexion a mongodb et insertion Temperature et humidite
//         
//         console.log(tempEtHum);

//     } //Fin if
// });